   String s = Integer.toString(n);
