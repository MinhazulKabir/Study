//Write MyBook class here
class MyBook extends Book {
    void setTitle(String s) {
        title = s;
    }
}
