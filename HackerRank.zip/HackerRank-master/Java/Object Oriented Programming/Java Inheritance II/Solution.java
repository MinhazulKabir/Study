//Write your code here

class Arithmetic {
    public Arithmetic() {}
    public Integer add(Integer a, Integer b) {
        return a + b;
    }
}

class Adder extends Arithmetic {
    public Adder(){}
}
