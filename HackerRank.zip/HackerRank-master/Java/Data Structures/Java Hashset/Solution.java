        HashSet<String> h = new HashSet<String>();
        for (int i = 0; i < t; i++) {
            h.add(pair_left[i] + " " + pair_right[i]);
            System.out.println(h.size());
        }
