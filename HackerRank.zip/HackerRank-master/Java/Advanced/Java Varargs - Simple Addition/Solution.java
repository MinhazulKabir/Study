class Add {
    public void add(int n1, int n2) {
        System.out.println(n1+"+"+n2+"="+((int)(n1+n2)));
    }

    public void add(int n1, int n2, int n3) {
        System.out.println(n1+"+"+n2+"+"+n3+"="+((int)(n1+n2+n3)));
    }

    public void add(int n1, int n2, int n3, int n4) {
        System.out.println(n1+"+"+n2+"+"+n3+"+"+n4+"="+((int)(n1+n2+n3+n4)));
    }

    public void add(int n1, int n2, int n3, int n4, int n5) {
        System.out.println(n1+"+"+n2+"+"+n3+"+"+n4+"+"+n5+"="+((int)(n1+n2+n3+n4+n5)));
    }

    public void add(int n1, int n2, int n3, int n4, int n5, int n6) {
        System.out.println(n1+"+"+n2+"+"+n3+"+"+n4+"+"+n5+"+"+n6+"="+((int)(n1+n2+n3+n4+n5+n6)));
    }
}
