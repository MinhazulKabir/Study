        return (order.equals("pizza")) ? new Pizza() : new Cake();
