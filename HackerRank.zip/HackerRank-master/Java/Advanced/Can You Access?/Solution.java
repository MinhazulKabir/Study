			o = (new Solution.Inner()).new Private();
            System.out.println("" + num + " is " + ((Solution.Inner.Private)o).powerof2(num));
