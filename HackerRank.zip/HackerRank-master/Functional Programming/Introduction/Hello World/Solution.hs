hello_world = putStrLn "Hello World"

-- This part relates to Input/Output and can be used as it is. Do not modify this section
main = do
   hello_world
