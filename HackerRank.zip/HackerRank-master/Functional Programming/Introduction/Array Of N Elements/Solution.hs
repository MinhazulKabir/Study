fn 0 = []
fn n = [i | i <- [1..n]]
