#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    long double b, a;
    cin >> b >> a;
    cout << (int)ceil(((a*2)/b));
    return 0;
}
